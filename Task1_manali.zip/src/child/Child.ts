import { Component } from "@angular/core";

@Component({
    selector:'child',
    template:`<input type='search' (input)='valueChange($event)' [value]="data" placeholder="search"/> 
    {{data}}
    <button>click</button> `
    
})
export class  ChildComponent{

    data='hello';
    valueChange(event){
        this.data=event.target.value;
        console.log(event.target.value);
    }
}